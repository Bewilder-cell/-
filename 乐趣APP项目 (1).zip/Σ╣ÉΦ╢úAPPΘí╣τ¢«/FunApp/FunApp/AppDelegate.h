//
//  AppDelegate.h
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/19.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

