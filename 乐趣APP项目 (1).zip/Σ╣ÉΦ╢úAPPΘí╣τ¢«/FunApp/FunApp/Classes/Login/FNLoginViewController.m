//
//  FNLoginViewController.m
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/20.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import "FNLoginViewController.h"
#import "FNTabBarController.h"
#import "FNRegistViewController.h"
#import "FNUserModel.h"

@interface FNLoginViewController ()
{
    BOOL switchType_;
}

@property (weak, nonatomic) IBOutlet UITextField *userField;
@property (weak, nonatomic) IBOutlet UITextField *pwdField;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UIButton *chooseButton;

@end

@implementation FNLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUpBase];
    
    [self setUpAcceptNote];
    
}


#pragma mark - 接收通知
- (void)setUpAcceptNote
{
    
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}



- (IBAction)chooseDefaultLogin:(UIButton *)sender {
    
    sender.selected = !sender.selected;
    
    [[SnToast new] dismissToast];
    
    switchType_ = sender.selected;
    
    [SnToast showBottomWithText:(switchType_) ? @"已开启记住密码" : @"已关闭记住密码"];
}


- (void)setUpBase
{
    if (![[NSUserDefaults standardUserDefaults] objectForKey:RememberPassword]) {
        self.chooseButton.selected = NO;
    }else{
        NSDictionary *userDict = [[NSUserDefaults standardUserDefaults] objectForKey:RememberPassword];
        self.userField.text = userDict[@"name"];
        self.pwdField.text = userDict[@"pwd"];
    }
}


#pragma mark - 登录点击
- (IBAction)loginClick:(id)sender {
    
    if (self.userField.text.length == 0 || self.pwdField.text.length == 0) {
        [SnToast showBottomWithText:@"请输入您的账号密码"];
        return;
    }
    
    if (![self.pwdField.text isEqualToString:[FNUserModel getCurrentUserPwd:self.userField.text]]) {
        [SnToast showBottomWithText:@"请输入正确的账号密码"];
        return;
    }
    
    if ([self.pwdField.text isEqualToString:[FNUserModel getCurrentUserPwd:self.userField.text]]) {
    
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            [SnToast showBottomWithText:@"登录成功"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [UIApplication sharedApplication].keyWindow.rootViewController = [[FNTabBarController alloc] init];;
                if (self->switchType_) {
                    NSMutableDictionary *userDict = [NSMutableDictionary dictionary];
                    [userDict setObject:self.userField.text forKey:@"name"];
                    [userDict setObject:self.pwdField.text forKey:@"pwd"];
                    [[NSUserDefaults standardUserDefaults] setObject:userDict forKey:RememberPassword];
                }else{
                    [[NSUserDefaults standardUserDefaults] removeObjectForKey:RememberPassword];
                }
                [[NSUserDefaults standardUserDefaults] setObject:self.userField.text forKey:UserName];
                [[NSUserDefaults standardUserDefaults] synchronize];
            });
        });
    }
}


#pragma mark - 注册
- (IBAction)registClick:(id)sender {
    
    FNRegistViewController *registVc = [FNRegistViewController new];
    [self.navigationController pushViewController:registVc animated:YES];
    
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}


- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end

