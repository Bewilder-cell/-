//
//  FNUserModel.m
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/21.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import "FNUserModel.h"

@implementation FNUserModel

#pragma mark - 联合主键
+ (NSArray *)bg_unionPrimaryKeys{
    return @[@"user_id",@"user_creat"];
}



+ (NSMutableArray<FNUserModel *>*)getAllUserArray
{
    NSMutableArray <FNUserModel *>*allArray = [NSMutableArray array];
    NSArray *allDataArray = [self bg_findAll:NOTEDBNAME];
    for (FNUserModel *eachItem in allDataArray) {
        [allArray addObject:eachItem];
    }
    return allArray;
}


+ (NSString *)getCurrentUserPwd:(NSString *)userName
{
    NSString *pwd;
    for (FNUserModel *eachItem in [self getAllUserArray]) {
        if ([userName isEqualToString:eachItem.user_name]) {
            pwd = eachItem.user_pwd;
            break;
        }
    }
    return pwd;
}


+ (FNUserModel *)getCurrentUserItem
{
    for (FNUserModel *eachItem in [self getAllUserArray]) {
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:UserName] isEqualToString:eachItem.user_name]) {
            return eachItem;
        }
    }
    return nil;
}

@end
