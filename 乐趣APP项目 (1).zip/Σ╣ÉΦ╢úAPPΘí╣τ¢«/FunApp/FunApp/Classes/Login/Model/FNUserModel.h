//
//  FNUserModel.h
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/21.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BGFMDB.h"

@interface FNUserModel : NSObject

/* ip */
@property (strong , nonatomic) NSString *user_id;

/* 注册时间 */
@property (strong , nonatomic) NSString *user_creat;

/* 用户头像 */
@property (strong , nonatomic) NSString *user_icon;

/* 用户名 */
@property (strong , nonatomic) NSString *user_name;

/* 用户密码 */
@property (strong , nonatomic) NSString *user_pwd;

/* 用户邮箱 */
@property (strong , nonatomic) NSString *user_email;


+ (NSMutableArray<FNUserModel *>*)getAllUserArray;


+ (NSString *)getCurrentUserPwd:(NSString *)userName;


+ (FNUserModel *)getCurrentUserItem;

@end
