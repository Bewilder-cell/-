//
//  FNRegistViewController.m
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/21.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import "FNRegistViewController.h"
#import "FNUserModel.h"


@interface FNRegistViewController ()
{
    NSInteger _loginCode;
}
@property (weak, nonatomic) IBOutlet UITextField *userField;
@property (weak, nonatomic) IBOutlet UITextField *pwdField;
@property (weak, nonatomic) IBOutlet UITextField *againPwdField;
@property (weak, nonatomic) IBOutlet UITextField *emailField;
@property (weak, nonatomic) IBOutlet UITextField *codeField;
@property (weak, nonatomic) IBOutlet UIButton *registButton;
@property (weak, nonatomic) IBOutlet UIButton *getCodeBtn;



@end

@implementation FNRegistViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}




#pragma mark - 注册用户
- (IBAction)registUer:(id)sender {
    
    [self.view endEditing:YES];
    
    
    
    if (self.userField.text.length == 0 || self.pwdField.text.length == 0 || self.againPwdField.text.length == 0 || self.emailField.text.length == 0 || self.codeField.text.length == 0) {
        [SnToast showBottomWithText:@"请输入全注册信息"];
        return;
    }
    
    
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    if (![emailTest evaluateWithObject:self.emailField.text]) {
        [SnToast showBottomWithText:@"请输入正确的邮箱账号"];
        return;
    }
    
    if (![self.pwdField.text isEqualToString: self.againPwdField.text]) {
        [SnToast showBottomWithText:@"两次输入密码信息必须相等"];
        return;
    }
    
    if ([FNUserModel getCurrentUserPwd:self.pwdField.text].length > 0) {
        [SnToast showBottomWithText:@"当前账户已经存在"];
        return;
    }
    
    if (![self.codeField.text isEqualToString:[NSString stringWithFormat:@"%zd",_loginCode]]) {
        [SnToast showBottomWithText:@"请输入正确的账号或者验证码"];
        return;
    }
    
    FNUserModel *newUser = [FNUserModel new];
    newUser.user_id = [NSString stringWithFormat:@"USER_%zd",[FNUserModel bg_findAll:NOTEDBNAME].count];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
    NSDate *datenow = [NSDate date];
    NSString *currentTimeString = [formatter stringFromDate:datenow];
    newUser.user_creat = currentTimeString;
    newUser.user_name = self.userField.text;
    newUser.user_pwd = self.pwdField.text;
    newUser.user_email = self.emailField.text;
    NSInteger index = 1 + (arc4random() % 5); // 1到5随机数
    newUser.user_icon = [NSString stringWithFormat:@"icon_%zd",index];
    newUser.bg_tableName = NOTEDBNAME;
    [newUser bg_saveOrUpdate];

    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    __weak typeof(self)weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        [SnToast showBottomWithText:@"注册成功"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf backLoginVc:nil];
        });
    });
    
}


#pragma mark - 获取验证码
- (IBAction)getCodeClick:(id)sender {
    
    [self.view endEditing:YES];
    
    
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    if (![emailTest evaluateWithObject:self.emailField.text]) {
        [SnToast showBottomWithText:@"请输入正确的邮箱账号"];
        return;
    }
    
    
    NSInteger one = (arc4random() % 10); // 0到10随机数
    NSInteger two = (arc4random() % 10);
    NSInteger three = (arc4random() % 10);
    NSInteger fourth = (arc4random() % 10);
    _loginCode = one * 1000 + two * 100 + three + 10 + fourth; // 四位数验证码
    
    [SnToast showBottomWithText:[NSString stringWithFormat:@"验证码：%zd",_loginCode]];
    
    __block NSInteger time = 59; //设置倒计时时间
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));
    
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0 * NSEC_PER_SEC, 0); //每秒执行
    __weak typeof(self)weakSelf = self;
    dispatch_source_set_event_handler(_timer, ^{
        
        if(time <= 0){ //倒计时结束，关闭
            
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                
                //设置按钮的样式
                [weakSelf.getCodeBtn setTitle:@"重新发送" forState:UIControlStateNormal];
                weakSelf.getCodeBtn.userInteractionEnabled = YES;
                
            });
            
        }else{
            
            NSInteger seconds = time % 60;
            dispatch_async(dispatch_get_main_queue(), ^{
                
                //设置按钮显示读秒效果
                [weakSelf.getCodeBtn setTitle:[NSString stringWithFormat:@"重新发送(%.2ld)", (long)seconds] forState:UIControlStateNormal];
                weakSelf.getCodeBtn.userInteractionEnabled = NO;
            });
            time--;
        }
    });
    dispatch_resume(_timer);
}


#pragma mark - 返回登录
- (IBAction)backLoginVc:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}


@end
