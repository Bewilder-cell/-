//
//  FNNewViewController.m
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/22.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import "FNNewViewController.h"

@interface FNNewViewController ()

@end

@implementation FNNewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUpBase];
    
    self.tableView.contentInset = UIEdgeInsetsMake(NavigationBarHeight, 0, tabBarHt, 0);
}


- (void)setUpBase
{
    self.navigationItem.title = @"最热";
    self.view.backgroundColor = [UIColor whiteColor];
}

@end
