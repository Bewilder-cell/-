//
//  FNNewViewController.h
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/22.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GFAllViewController.h"

@interface FNNewViewController : GFAllViewController

@end
