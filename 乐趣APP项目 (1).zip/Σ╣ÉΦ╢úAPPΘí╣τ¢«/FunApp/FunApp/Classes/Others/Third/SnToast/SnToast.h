//
//  SnToast.h
//  SnailChat
//
//  Created by Pluto on 16/10/8.
//  Copyright © 2018年 linfei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define DEFAULT_DISPLAY_DURATION 2.0f

@interface SnToast : NSObject {
    NSString *text;
    UIButton *contentView;
    CGFloat  duration;
}
-(void)dismissToast;

+ (void)showWithText:(NSString *) text_;
+ (void)showWithText:(NSString *) text_
            duration:(CGFloat)duration_;

+ (void)showWithText:(NSString *) text_
           topOffset:(CGFloat) topOffset_;
+ (void)showWithText:(NSString *) text_
           topOffset:(CGFloat) topOffset
            duration:(CGFloat) duration_;

+ (void)showWithText:(NSString *) text_
        bottomOffset:(CGFloat) bottomOffset_;
+ (void)showWithText:(NSString *) text_
        bottomOffset:(CGFloat) bottomOffset_
            duration:(CGFloat) duration_;
+ (SnToast*)showBottomWithText:(NSString *)text_;
+ (SnToast*)showBottomKeyboardWithText:(NSString *)text_;
@end
