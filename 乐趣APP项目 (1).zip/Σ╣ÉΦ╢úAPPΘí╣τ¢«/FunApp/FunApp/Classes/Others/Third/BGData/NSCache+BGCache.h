//
//  NSCache+BGCache.h
//  BGFMDB
//
//  Created by biao on 2017/10/17.
//  Copyright © 2017年 Biao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSCache (BGCache)

+(instancetype)bg_cache;

@end
