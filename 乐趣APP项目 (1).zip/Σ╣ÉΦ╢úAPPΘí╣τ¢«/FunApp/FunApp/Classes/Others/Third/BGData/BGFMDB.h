//
//  BGFMDB.h
//  BGFMDB
//
//  Created by biao on 2017/10/18.
//  Copyright © 2017年 Biao. All rights reserved.
//

#ifndef BGFMDB_h
#define BGFMDB_h

#import "NSObject+BGModel.h"

#endif /* BGFMDB_h */
