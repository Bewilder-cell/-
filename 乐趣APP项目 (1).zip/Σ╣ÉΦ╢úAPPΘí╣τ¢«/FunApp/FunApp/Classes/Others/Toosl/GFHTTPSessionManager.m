//
//  GFHTTPSessionManager.m
//  GFBS
//
//  Created by apple on 2016/11/25.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "GFHTTPSessionManager.h"

@implementation GFHTTPSessionManager

-(instancetype)initWithBaseURL:(NSURL *)url
{
    if (self = [super initWithBaseURL:url]) {
        
        
    }
    return self;
}

@end
