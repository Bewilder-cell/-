//
//  GFRefreshHeader.h
//  GFBS
//
//  Created by apple on 2016/11/25.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface GFRefreshHeader : MJRefreshNormalHeader

@end
