//
//  NPQuickMethod.h
//  CDDKit
//
//  Created by Pluto on 2019/12/18.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NPQuickMethod : NSObject


/**
 设置按钮的圆角加边线

 @param anyControl 控件
 @param radius 圆角
 @param width 宽度
 @param borderColor 边线颜色
 @param can 是否可以裁剪
 @return 制作以后得控件
 */
+(instancetype)dc_chageControlCircularWith:(id)anyControl AndSetCornerRadius:(NSInteger)radius SetBorderWidth:(NSInteger)width SetBorderColor:(UIColor *)borderColor canMasksToBounds:(BOOL)can;

/**
 字符串加星处理
 
 @param content NSString字符串
 @param findex 第几位开始加星
 @return 返回加星后的字符串
 */
+ (NSString *)dc_encryptionDisplayMessageWith:(NSString *)content WithFirstIndex:(NSInteger)findex;

/**
 图片转base64编码

 @param image 图片
 @return base64编码
 */
+ (NSString *)dc_imageToBase64Str:(UIImage *) image;

/**
 base64图片转编码

 @param _encodedImageStr 图片的base64码
 @return 图片
 */
+ (UIImage *)dc_base64StrToUIImage:(NSString *)_encodedImageStr;


/**
 根据传入字体大小计算字体宽高

 @param text 传入的字体
 @param textFont 字体的Font
 @param maxW 字体的行数的最大宽度
 @return 返回字体的宽高
 */
+ (CGSize)dc_calculateTextSizeWithText : (NSString *)text WithTextFont: (NSInteger)textFont WithMaxW : (CGFloat)maxW;

/**
 更改iOS状态栏的颜色

 @param color 更换的颜色
 */
+ (void)dc_setStatusBarBackgroundColor:(UIColor *)color;

/**
 为控制器添加背景图片

 @param imageName 图片
 @param viewController 控制器
 */
+ (void)dc_addBackgroundImageWithImageName:(NSString *)imageName forViewController:(UIViewController *)viewController;



/**
 自定义弹框

 @param vc 当前页面
 @param message 消息
 @param sureBlock 确定回调
 @param cancelBlock 取消回调
 */
+ (void)dc_SetUpAlterWithView:(UIViewController *)vc Message:(NSString *)message Sure:(dispatch_block_t)sureBlock Cancel:(dispatch_block_t)cancelBlock;

/**
 选取部分数据变色（label）

 @param label label label
 @param arrray arrray 变色数组
 @param color color 变色颜色
 @return label
 */
+(id)dc_setSomeOneChangeColor:(UILabel *)label SetSelectArray:(NSArray *)arrray SetChangeColor:(UIColor *)color;


/**
 利用贝塞尔曲线设置圆角
 
 @param control 按钮
 @param size 圆角尺寸
 */
+ (void)dc_setUpBezierPathCircularLayerWithControl:(UIButton *)control size:(CGSize)size;


/**
 弹框
 
 @param currVc 当前控制器
 @param content 提示内容
 @param leftMsg 左边按钮
 @param leftClickBlock 回调
 @param rightMsg 右边按钮
 @param rightClickBlock 回调
 */
+ (void)setUpAlterViewWith:(UIViewController *)currVc WithReadContent:(NSString *)content WithLeftMsg:(NSString *)leftMsg LeftBlock:(dispatch_block_t)leftClickBlock RightMsg:(NSString *)rightMsg RightBliock:(dispatch_block_t)rightClickBlock;

/**
 输入时间合适NSDate

 @param NSString 字符串
 @return 星期
 */
#pragma mark -  返回当前日期
+ (NSString *)dc_weekdayStringFromDate:(NSDate*)inputDate;

/**
 根据当前日期返回几月几日
 */
+ (NSArray *)dc_getNowMonthAndDay;



/**
 字典转Json
 */
+ (NSString *)dc_dictionaryToJson:(NSDictionary *)dic;

/**
 编码
 */
+ (NSString *)dc_encode:(NSString *)string;

/**
 解码
 */
+ (NSString *)dc_dencode:(NSString *)base64String;

#pragma mark - 获取当前屏幕显示的VC

/**
 获取当前屏幕显示的VC
 */
+ (UIViewController *)dc_getCurrentVC;

/**
 触动
 */
+ (void)dc_callFeedbackWithStyle:(UIImpactFeedbackStyle)style;


/**
 倒计时

 @param countTime 时间
 @param endBlock 结束回调
 */
+ (void)dc_countdownWithTime:(NSInteger)countTime With:(dispatch_block_t)endBlock;


/**
 数组

 @param target self
 @param action action
 @param norImage image
 @param hImage image
 @return value
 */
+ (NSArray *)dc_setUpBarItemsWithAddTarget:(nullable id)target action:(SEL _Nullable )action WithNormalImage:(NSString *_Nullable)norImage HightImage:(NSString *_Nonnull)hImage;

/**
 sheet弹框

 @param showVc 当前控制器
 @param title 标题
 @param message 内容
 @param contentArray sheet Item 名数组
 @param cancelTitle 取消事件名
 @param cancelBlock 取消回调
 @param contentBlock sheet Item 名数组 回调
 @param completionBlock 完成回调
 */
+ (void)dc_SetUpSheetWithView:(UIViewController *)showVc WithTitle:(NSString *)title Message:(NSString *)message ContentArray:(NSArray *)contentArray CancelTitle:(NSString *)cancelTitle CancelBlock:(dispatch_block_t)cancelBlock ContentClickBlock:(void(^)(NSInteger index , NSString *titleName))contentBlock CompletionBlock:(dispatch_block_t)completionBlock;


/**
 设置圆角

 @param control 控件
 @param rad 圆角
 */
+ (void)dc_setUpCornerRadiusWithCotrol:(UIView *)control radius:(CGFloat)rad;


/**
 获取当前时间戳

 @return 返回时间
 */
+ (UInt64)dc_getCurrentimestamp;

+ (UIViewController *)getCurrentVCFrom:(UIViewController *)rootVC;

/**
 sheet弹框

 @param currVc 当前控制器
 @param title 标题
 @param doContent 做的事
 @param doBlock 回调
 */
+ (void)setUpAlterViewWithSheetController:(UIViewController *)currVc WithTitle:(NSString *)title DoTitle:(NSString *)doContent WithDoBlock:(dispatch_block_t)doBlock;

@end
