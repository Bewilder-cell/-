//
//  GFHTTPSessionManager.h
//  GFBS
//
//  Created by apple on 2016/11/25.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>

@interface GFHTTPSessionManager : AFHTTPSessionManager

@end
