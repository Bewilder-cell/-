//
//  NPQuickMethod.m
//  CDDKit
//
//  Created by Pluto on 2019/12/18.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import "NPQuickMethod.h"
#import "AppDelegate.h"

@implementation NPQuickMethod

#pragma mark - 设置按钮的圆角加边线
+ (instancetype)dc_chageControlCircularWith:(id)anyControl AndSetCornerRadius:(NSInteger)radius SetBorderWidth:(NSInteger)width SetBorderColor:(UIColor *)borderColor canMasksToBounds:(BOOL)can
{
    CALayer *icon_layer=[anyControl layer];
    [icon_layer setCornerRadius:radius];
    [icon_layer setBorderWidth:width];
    [icon_layer setBorderColor:[borderColor CGColor]];
    [icon_layer setMasksToBounds:can];
    
    return anyControl;
}

#pragma mark - 根据传入字体大小计算字体宽高
+ (CGSize)dc_calculateTextSizeWithText : (NSString *)text WithTextFont: (NSInteger)textFont WithMaxW : (CGFloat)maxW {
    
    CGFloat textMaxW = maxW;
    CGSize textMaxSize = CGSizeMake(textMaxW, MAXFLOAT);
    
    //可以更改尺寸
    CGSize textSize = [text boundingRectWithSize:textMaxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:textFont]} context:nil].size;
    
    return textSize;
}


#pragma mark - 字符串加星处理
+ (NSString *)dc_encryptionDisplayMessageWith:(NSString *)content WithFirstIndex:(NSInteger)findex
{
    if (findex <= 0) {
        findex = 2;
    }else if (findex + 1 > content.length) {
        findex --;
    }
    return [NSString stringWithFormat:@"%@***%@",[content substringToIndex:findex],[content substringFromIndex:content.length - 1]];
}


#pragma mark - 图片转base64编码
+ (NSString *)dc_imageToBase64Str:(UIImage *) image
{
    NSData *data = UIImageJPEGRepresentation(image, 1.0f);
    NSString *encodedImageStr = [data base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    return encodedImageStr;
}

#pragma mark - base64图片转编码
+ (UIImage *)dc_base64StrToUIImage:(NSString *)_encodedImageStr
{
    NSData *_decodedImageData = [[NSData alloc] initWithBase64EncodedString:_encodedImageStr options:NSDataBase64DecodingIgnoreUnknownCharacters];
    UIImage *_decodedImage = [UIImage imageWithData:_decodedImageData];
    return _decodedImage;
}

#pragma mark - 更改iOS状态栏的颜色
+ (void)dc_setStatusBarBackgroundColor:(UIColor *)color
{
//    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
//    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]){
//        statusBar.backgroundColor = color;
//    }
}


#pragma mark - 为控制器添加背景图片
+ (void)dc_addBackgroundImageWithImageName:(NSString *)imageName forViewController:(UIViewController *)viewController
{
    //给控制器添加背景图片
    UIImage *oldImage = [UIImage imageNamed:imageName];
    UIGraphicsBeginImageContextWithOptions(viewController.view.frame.size, NO, 0.0);
    [oldImage drawInRect:viewController.view.bounds];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    viewController.view.backgroundColor = [UIColor colorWithPatternImage:newImage];
}

#pragma mark - 弹框
+ (void)dc_SetUpAlterWithView:(UIViewController *)vc Message:(NSString *)message Sure:(dispatch_block_t)sureBlock Cancel:(dispatch_block_t)cancelBlock
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    //取消
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action){
        !cancelBlock ? : cancelBlock();
    }];
    //确定
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        !sureBlock ? : sureBlock();
    }];
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    
    [vc presentViewController:alertController animated:YES completion:nil];
}

#pragma mark - 设置圆角
+ (void)dc_setUpBezierPathCircularLayerWithControl:(UIButton *)control size:(CGSize)size;
{
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:control.bounds byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight | UIRectCornerTopLeft |UIRectCornerTopRight cornerRadii:size];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = control.bounds;
    maskLayer.path = maskPath.CGPath;
    control.layer.mask = maskLayer;
}


#pragma mark - 改颜色
+(id)dc_setSomeOneChangeColor:(UILabel *)label SetSelectArray:(NSArray *)arrray SetChangeColor:(UIColor *)color
{
    if (label.text.length == 0) {
        return 0;
    }
    int i;
    NSMutableAttributedString *attributeString  = [[NSMutableAttributedString alloc]initWithString:label.text];
    for (i = 0; i < label.text.length; i ++) {
        NSString *a = [label.text substringWithRange:NSMakeRange(i, 1)];
        NSArray *number = arrray;
        if ([number containsObject:a]) {
            [attributeString setAttributes:@{NSForegroundColorAttributeName:color} range:NSMakeRange(i, 1)];
        }
    }
    label.attributedText = attributeString;
    return label;
}

#pragma mark - 弹框
+ (void)setUpAlterViewWith:(UIViewController *)currVc WithReadContent:(NSString *)content WithLeftMsg:(NSString *)leftMsg LeftBlock:(dispatch_block_t)leftClickBlock RightMsg:(NSString *)rightMsg RightBliock:(dispatch_block_t)rightClickBlock
{
    UIAlertController *alter = [UIAlertController alertControllerWithTitle:@"温馨提示" message:content preferredStyle:UIAlertControllerStyleAlert];
    
    if (leftMsg.length != 0) {
        
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:leftMsg style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            !leftClickBlock ? : leftClickBlock();
        }];
        [alter addAction:okAction];
        
    }
    
    if (rightMsg.length != 0) {
        
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:rightMsg style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            
            !rightClickBlock ? : rightClickBlock();
        }];
        [alter addAction:okAction];
        
    }
    
    [currVc presentViewController:alter animated:YES completion:nil];
}

#pragma mark -  返回当前日期
+ (NSString *)dc_weekdayStringFromDate:(NSDate*)inputDate {
    NSArray *weekdays = [NSArray arrayWithObjects: [NSNull null], @"周末", @"周一", @"周二", @"周三", @"周四", @"周五", @"周六", nil];
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSTimeZone *timeZone = [[NSTimeZone alloc] initWithName:@"Asia/Shanghai"];
    [calendar setTimeZone: timeZone];
    NSCalendarUnit calendarUnit = NSCalendarUnitWeekday;
    NSDateComponents *theComponents = [calendar components:calendarUnit fromDate:inputDate];
    return [weekdays objectAtIndex:theComponents.weekday];
}


#pragma mark - 根据当前日期返回几月几日
+ (NSArray *)dc_getNowMonthAndDay
{
    NSString *month,*day;
    //1.获取当月的总天数
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSRange range = [calendar rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:[NSDate date]];
    NSUInteger numberOfDaysInMonth = range.length;
    NSLog(@"%lu", (unsigned long)numberOfDaysInMonth);
    //2.获取当前年份, 月份, 号数
    unsigned unitFlags = NSCalendarUnitYear |NSCalendarUnitMonth |NSCalendarUnitDay;
    NSDateComponents *components = [calendar components:unitFlags fromDate:[NSDate date]];
    NSLog(@"%ld, %ld, %ld", (long)components.year, (long)components.month, (long)components.day);
    day = [NSString stringWithFormat:@"%ld",components.day];
    //根据月份返回英文状态字符串
    switch (components.month) {
        case 1:
            month = @"Jan";
            break;
        case 2:
            month = @"Feb";
            break;
        case 3:
            month = @"Mar";
            break;
        case 4:
            month = @"Apr";
            break;
        case 5:
            month = @"May";
            break;
        case 6:
            month = @"Jun";
            break;
        case 7:
            month = @"Jul";
            break;
        case 8:
            month = @"Aug";
            break;
        case 9:
            month = @"Sep";
            break;
        case 10:
            month = @"Oct";
            break;
        case 11:
            month = @"Nov";
            break;
        default:
            month = @"Dec";
            break;
    }
    
    return @[month,day];
}

#pragma mark - 字典转Json
+ (NSString*)dc_dictionaryToJson:(NSDictionary *)dic
{
    NSError *error;
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&error];
    
    NSString *jsonString;
    
    if (!jsonData) {
        NSLog(@"%@",error);
    }else{
        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    NSMutableString *mutStr = [NSMutableString stringWithString:jsonString];
    NSRange range = {0,jsonString.length};
    
    //去掉字符串中的空格
    [mutStr replaceOccurrencesOfString:@" " withString:@"" options:NSLiteralSearch range:range];
    NSRange range2 = {0,mutStr.length};
    
    //去掉字符串中的换行符
    [mutStr replaceOccurrencesOfString:@"\n" withString:@"" options:NSLiteralSearch range:range2];
    
    return mutStr;
}


#pragma mark - 64编码
+ (NSString *)dc_encode:(NSString *)string
{
    //先将string转换成data
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    
    NSData *base64Data = [data base64EncodedDataWithOptions:0];
    
    NSString *baseString = [[NSString alloc]initWithData:base64Data encoding:NSUTF8StringEncoding];
    
    return baseString;
}

#pragma mark - 64解码
+ (NSString *)dc_dencode:(NSString *)base64String
{
    //NSData *base64data = [string dataUsingEncoding:NSUTF8StringEncoding];
    
    NSData *data = [[NSData alloc]initWithBase64EncodedString:base64String options:NSDataBase64DecodingIgnoreUnknownCharacters];
    
    NSString *string = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    
    return string;
}

#pragma mark - 获取当前屏幕显示的VC
+ (UIViewController *)dc_getCurrentVC
{
//    UIViewController *rootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
//
//    UIViewController *currentVC = [self getCurrentVCFrom:rootViewController];
//
    return 0;
}

+ (UIViewController *)getCurrentVCFrom:(UIViewController *)rootVC
{
    UIViewController *currentVC;
    
    if([rootVC presentedViewController]) {
        // 视图是被presented出来的
        rootVC = [rootVC presentedViewController];
    }
    if([rootVC isKindOfClass:[UITabBarController class]]) {
        // 根视图为UITabBarController
        currentVC = [self getCurrentVCFrom:[(UITabBarController *)rootVC selectedViewController]];
        
    }else if([rootVC isKindOfClass:[UINavigationController class]]){
        // 根视图为UINavigationController
        currentVC = [self getCurrentVCFrom:[(UINavigationController *)rootVC visibleViewController]];
        
    }else{
        // 根视图为非导航类
        currentVC = rootVC;
    }
    return currentVC;
}

#pragma mark - 触动
+ (void)dc_callFeedbackWithStyle:(UIImpactFeedbackStyle)style
{
    if (@available(iOS 10.0, *)) {
        UIImpactFeedbackGenerator *generator = [[UIImpactFeedbackGenerator alloc] initWithStyle: style];
        [generator prepare];
        [generator impactOccurred];
    }
}


#pragma mark - 倒计时
+ (void)dc_countdownWithTime:(NSInteger)countTime With:(dispatch_block_t)endBlock
{
    __block NSInteger time = countTime; //设置倒计时时间
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));
    
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0 * NSEC_PER_SEC, 0); //每秒执行
    
    dispatch_source_set_event_handler(_timer, ^{
        
        if(time <= 0){ //倒计时结束，关闭
            
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                
                !endBlock ? : endBlock();
            });
            
        }else{
            time--;
        }
    });
    dispatch_resume(_timer);
}


+ (NSArray *)dc_setUpBarItemsWithAddTarget:(nullable id)target action:(SEL _Nullable )action WithNormalImage:(NSString *_Nullable)norImage HightImage:(NSString *_Nonnull)hImage
{
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    negativeSpacer.width = -15;
    
    UIButton *button = [[UIButton alloc] init];
    [button setImage:[UIImage imageNamed:norImage] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:hImage] forState:UIControlStateHighlighted];
    button.frame = CGRectMake(0, 0, 33, 33);    
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    return @[negativeSpacer, backButton];
}

#pragma mark - sheet弹框
+ (void)dc_SetUpSheetWithView:(UIViewController *)showVc WithTitle:(NSString *)title Message:(NSString *)message ContentArray:(NSArray *)contentArray CancelTitle:(NSString *)cancelTitle CancelBlock:(dispatch_block_t)cancelBlock ContentClickBlock:(void(^)(NSInteger index , NSString *titleName))contentBlock CompletionBlock:(dispatch_block_t)completionBlock
{
    NSString *aTitle = (title.length > 0 || title != nil) ? title : nil;
    NSString *aMessage = (message.length > 0 || message != nil) ? message : nil;
    UIAlertController *sheetController = [UIAlertController alertControllerWithTitle:aTitle message:aMessage preferredStyle:UIAlertControllerStyleActionSheet];
    
    if ((cancelTitle.length > 0 || cancelTitle != nil)) { //UIAlertActionStyleCancel
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            !cancelBlock ? : cancelBlock();
        }];
        [sheetController addAction:cancelAction];
    }

    if (contentArray.count == 0) return;
    for (NSInteger  i = 0; i < contentArray.count; i++) {
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:contentArray[i] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            !contentBlock ? : contentBlock(i , contentArray[i]);
        }];
        [sheetController addAction:action];
    }
    
    [showVc presentViewController:sheetController animated:YES completion:completionBlock];
}


#pragma mark - 设置圆角
+ (void)dc_setUpCornerRadiusWithCotrol:(UIView *)control radius:(CGFloat)rad;
{
    control.layer.cornerRadius = rad;
    control.layer.masksToBounds = YES;
}

#pragma mark - 获取当前时间戳
+ (UInt64)dc_getCurrentimestamp
{
    return [[NSDate date] timeIntervalSince1970] *1000;
}


#pragma mark - Sheet弹框
+ (void)setUpAlterViewWithSheetController:(UIViewController *)currVc WithTitle:(NSString *)title DoTitle:(NSString *)doContent WithDoBlock:(dispatch_block_t)doBlock
{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:title message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [controller addAction:[UIAlertAction actionWithTitle:doContent style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        
        !doBlock ? : doBlock();
    }]];
    
    [controller addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [currVc presentViewController:controller animated:YES completion:nil];
}

@end
