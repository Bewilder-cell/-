//
//  GFTopViewController.h
//  GFBS
//
//  Created by apple on 2016/12/6.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GFTopViewController : UIViewController

@end
