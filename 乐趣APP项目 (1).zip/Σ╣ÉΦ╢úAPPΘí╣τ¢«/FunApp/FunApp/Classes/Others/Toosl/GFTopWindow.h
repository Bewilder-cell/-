//
//  GFTopWindow.h
//  GFBS
//
//  Created by apple on 2016/12/6.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface GFTopWindow : UIWindow

/**
 显示
 */
+(void)gf_show;

/**
 影藏
 */
+ (void)gf_hide;

@end
