//
//  NSCalendar+GFExtension.h
//  GFBS
//
//  Created by apple on 2016/11/26.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSCalendar (GFExtension)

+(instancetype)gf_calendar;

@end
