//
//  NPConst.h
//  CDDKit
//
//  Created by apple on 2017/10/8.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NPConst : NSObject

//屏幕宽度
#define DCScreenW \
([[UIScreen mainScreen] respondsToSelector:@selector(nativeBounds)] ? [UIScreen mainScreen].nativeBounds.size.width/[UIScreen mainScreen].nativeScale : [UIScreen mainScreen].bounds.size.width)
//屏幕高度
#define DCScreenH \
([[UIScreen mainScreen] respondsToSelector:@selector(nativeBounds)] ? [UIScreen mainScreen].nativeBounds.size.height/[UIScreen mainScreen].nativeScale : [UIScreen mainScreen].bounds.size.height)

#define IsLHDevice  ([[UIScreen mainScreen] respondsToSelector:@selector(nativeBounds)] ? [UIScreen mainScreen].nativeBounds.size.height/[UIScreen mainScreen].nativeScale : [UIScreen mainScreen].bounds.size.height > 800.0)

#define NavigationBarHeight     (IsLHDevice ? 88 : 64)
#define tabBarHt (IsLHDevice) ? 83.0f : 49.0f
#define staBarHt (IsLHDevice == YES) ? 44.0f : 20.0f

/** 常量数(间隔) */
UIKIT_EXTERN CGFloat const DCMargin;


/** 数据库名称 */
UIKIT_EXTERN NSString * const NOTEDBNAME;


/** 记住密码 */
UIKIT_EXTERN NSString * const RememberPassword;

/** 用户名 */
UIKIT_EXTERN NSString * const UserName;

/** 退出登录 */
UIKIT_EXTERN NSString * const loginOff;

@end
