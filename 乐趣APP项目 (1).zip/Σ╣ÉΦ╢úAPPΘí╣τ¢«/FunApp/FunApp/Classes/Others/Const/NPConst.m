//
//  NPConst.m
//  CDDKit
//
//  Created by apple on 2017/10/8.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import "NPConst.h"

@implementation NPConst

/** 常量数 */
CGFloat const DCMargin = 10;

NSString * const RememberPassword = @"RememberPassword";

NSString * const NOTEDBNAME = @"CHEN_NOTEDB";

NSString * const loginOff = @"loginOff";


NSString * const UserName = @"UserName";

@end
