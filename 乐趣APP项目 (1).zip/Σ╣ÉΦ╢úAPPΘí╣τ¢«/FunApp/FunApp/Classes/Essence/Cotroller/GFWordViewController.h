//
//  GFWordViewController.h
//  GFBS
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GFTopicViewController.h"

@interface GFWordViewController : GFTopicViewController

@end
