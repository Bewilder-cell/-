//
//  GFSeeBigImageViewController.h
//  GFBS
//
//  Created by apple on 2016/11/28.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GFTopic;
@interface GFSeeBigImageViewController : UIViewController

/*模型*/
@property (strong ,nonatomic) GFTopic *topic;

@end
