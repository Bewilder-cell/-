//
//  GFWordViewController.m
//  GFBS
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "GFWordViewController.h"

@interface GFWordViewController ()

@end

@implementation GFWordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
}

-(GFTopicType)type
{
    return GFTopicTypeWord;
}

@end
