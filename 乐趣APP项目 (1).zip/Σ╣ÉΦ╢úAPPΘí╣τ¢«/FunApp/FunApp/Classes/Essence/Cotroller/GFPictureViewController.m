//
//  GFPictureViewController.m
//  GFBS
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "GFPictureViewController.h"

@interface GFPictureViewController ()

@end

@implementation GFPictureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(GFTopicType)type
{
    return GFTopicTypePicture;
}

@end
