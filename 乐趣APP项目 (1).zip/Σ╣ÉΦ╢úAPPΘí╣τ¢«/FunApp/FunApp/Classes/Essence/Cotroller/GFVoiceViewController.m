//
//  GFVoiceViewController.m
//  GFBS
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "GFVoiceViewController.h"

@interface GFVoiceViewController ()

@end

@implementation GFVoiceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(GFTopicType)type
{
    return GFTopicTypeVoice;
}


@end
