//
//  GFAllViewController.m
//  GFBS
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "GFAllViewController.h"


@interface GFAllViewController ()

@end

@implementation GFAllViewController


- (void)viewDidLoad {
    [super viewDidLoad];


}

-(GFTopicType)type
{
    return GFTopicTypeAll;
}




@end
