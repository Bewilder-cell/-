//
//  GFTopicCell.m
//  GFBS
//
//  Created by apple on 2016/11/25.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "GFTopicCell.h"
#import "GFTopic.h"
#import "GFComment.h"
#import "GFUser.h"
#import "FNLikeModel.h"
#import "FNCollectionModel.h"
#import "FNUserModel.h"

#import "GFTopicVideoView.h"
#import "GFTopicVoiceView.h"
#import "GFTopicPictureView.h"

#import <SVProgressHUD.h>
#import <Social/Social.h>
#import <UIImageView+WebCache.h>


@interface GFTopicCell()
@property (weak, nonatomic) IBOutlet UIImageView *profileImageView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *createdAtLabel;
@property (weak, nonatomic) IBOutlet UILabel *text_label;


@property (weak, nonatomic) IBOutlet UIView *topCommentView;
@property (weak, nonatomic) IBOutlet UILabel *topCommentLabel;


/*图片View*/
@property (weak ,nonatomic) GFTopicPictureView *pictureView;
/*声音View*/
@property (weak ,nonatomic) GFTopicVoiceView *voiceView;
/*视频View*/
@property (weak ,nonatomic) GFTopicVideoView *videoView;

@property (weak, nonatomic) IBOutlet UIButton *likeButton;
@property (weak, nonatomic) IBOutlet UIButton *collectionButton;
@property (weak, nonatomic) IBOutlet UILabel *likeLabel;
@property (weak, nonatomic) IBOutlet UILabel *collectionLabel;



@end

@implementation GFTopicCell

#pragma mark - 懒加载
-(GFTopicPictureView *)pictureView
{
    if (!_pictureView) {
        _pictureView = [GFTopicPictureView gf_viewFromXib];
        [self.contentView addSubview:_pictureView];
    }
    return _pictureView;
}

-(GFTopicVideoView *)videoView
{
    if (!_videoView) {
        _videoView = [GFTopicVideoView gf_viewFromXib];
        [self.contentView addSubview:_videoView];
    }
    return _videoView;
}

-(GFTopicVoiceView *)voiceView
{
    if (!_voiceView) {
        _voiceView = [GFTopicVoiceView gf_viewFromXib];
        [self.contentView addSubview:_voiceView];
    }
    return _voiceView;
}


#pragma mark - 点赞评论
- (IBAction)likeClick:(UIButton *)sender {
    
    sender.selected = !sender.selected;
    
    FNLikeModel *likeModel = [FNLikeModel new];
    likeModel.like_id = _topic.ID;
    likeModel.like_content = _topic.text;
    if (sender.selected) {
        _likeLabel.text = @"已赞";
        _likeLabel.textColor = UIColor.redColor;
        [FNLikeModel addLikeContentWith:likeModel];
        [SnToast showBottomWithText:@"已赞"];
    }else{
        _likeLabel.text = @"点赞";
        _likeLabel.textColor = UIColor.darkGrayColor;
        [FNLikeModel remoLikeContentWith:likeModel];
        [SnToast showBottomWithText:@"取消"];
    }
    
}

- (IBAction)collectionClick:(UIButton *)sender {
    
    FNCollectionModel *colModel = [FNCollectionModel new];
    colModel.col_id = _topic.ID;
    colModel.col_content = _topic.text;
    colModel.topic = _topic;
    
    sender.selected = !sender.selected;
    if (sender.selected) {
        _collectionLabel.text = @"已收藏";
        _collectionLabel.textColor = UIColor.redColor;
        [FNCollectionModel addColContentWith:colModel];
        [SnToast showBottomWithText:@"已收藏"];
    }else{
        _collectionLabel.text = @"收藏";
        _collectionLabel.textColor = UIColor.darkGrayColor;
        [FNCollectionModel remoColContentWith:colModel];
        [SnToast showBottomWithText:@"取消收藏"];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"UPDATECOLLECTIONDATA" object:nil];
}


-(void)setTopic:(GFTopic *)topic
{
    _topic = topic;
    
    if ([FNLikeModel isAddLikeContentWith:topic.ID]) {
        _likeButton.selected = true;
        _likeLabel.text = @"已赞";
        _likeLabel.textColor = UIColor.redColor;
    }else{
        _likeButton.selected = false;
        _likeLabel.text = @"点赞";
        _likeLabel.textColor = UIColor.darkGrayColor;
    }
    
    if ([FNCollectionModel isAddColContentWith:topic.ID]) {
        _collectionButton.selected = true;
        _collectionLabel.text = @"已收藏";
        _collectionLabel.textColor = UIColor.redColor;
    }else{
        _collectionButton.selected = false;
        _collectionLabel.text = @"收藏";
        _collectionLabel.textColor = UIColor.darkGrayColor;
    }
  
    if ([topic.profile_image isEqualToString:@"me"]) {
        self.profileImageView.image = [UIImage imageNamed:[FNUserModel getCurrentUserItem].user_icon];
    }else {
      UIImage *placeholder = [[UIImage imageNamed:@"defaultUserIcon"] gf_circleImage];
      [self.profileImageView sd_setImageWithURL:[NSURL URLWithString:topic.profile_image] placeholderImage:placeholder completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
          if (!image) return ;
          self.profileImageView.image = [image gf_circleImage];
      }];
    }
    
    self.nameLabel.text = topic.name;
    
    //日期处理
    self.createdAtLabel.text = topic.created_at;
    self.text_label.text = topic.text;
    
    //最热评论显示或者隐藏
    if (topic.top_cmt) {//有最热评论
        self.topCommentView.hidden = NO;
        
        //展示评论数据
        NSString *content = topic.top_cmt.content;
        NSString *username = topic.top_cmt.user.username;
        
        self.topCommentLabel.text = [NSString stringWithFormat:@"%@ : %@",username,content];
        
    }else{//没有最热评论
        
        self.topCommentView.hidden = YES;
    }
    
#pragma mark - 根据类型判断
    if (topic.type == GFTopicTypeWord) {//段子
        self.pictureView.hidden = YES;
        self.videoView.hidden = YES;
        self.voiceView.hidden = YES;
        
    }else if (topic.type == GFTopicTypePicture){//图片
        
        self.pictureView.hidden = NO;
        self.pictureView.frame = topic.middleF;
        self.pictureView.topic = topic;
        
        self.videoView.hidden = YES;
        self.voiceView.hidden = YES;
        
    }else if (topic.type == GFTopicTypeVideo){//声音
        
        self.videoView.hidden = NO;
        self.videoView.frame = topic.middleF;
        self.videoView.topic = topic;
        
        self.pictureView.hidden = YES;
        self.voiceView.hidden = YES;
        
    }else if (topic.type == GFTopicTypeVoice){//视频
        
        self.voiceView.hidden = NO;
        self.voiceView.frame = topic.middleF;
        self.voiceView.topic = topic;
        
        self.pictureView.hidden = YES;
        self.videoView.hidden = YES;
        
    }
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    
    
}

/**
 设置按钮数字
 */
-(void)setUpButton:(UIButton *)button number:(NSInteger)number placeholder:(NSString *)placeholder
{
    if (number >= 10000) {
        [button setTitle:[NSString stringWithFormat:@"%.1f万",number / 10000.0] forState:UIControlStateNormal];
    }else if (number > 0){
        [button setTitle:[NSString stringWithFormat:@"%zd",number] forState:UIControlStateNormal];
    }else{
        [button setTitle:placeholder forState:UIControlStateNormal];
    }
}

-(void)awakeFromNib
{
    [super awakeFromNib];
    
    self.backgroundView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"mainCellBackgroung"]];
}

/**
 重写这个方法：拦截所有cell frame的设置
 */
-(void)setFrame:(CGRect)frame
{
    frame.size.height -= GFMargin;
    frame.origin.y += GFMargin;
    
    [super setFrame:frame];
}


@end
