//
//  GFTopicPictureView.h
//  GFBS
//
//  Created by apple on 2016/11/27.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>


@class GFTopic;
@interface GFTopicPictureView : UIView

/*图片数据*/
@property (strong , nonatomic)GFTopic *topic;

@end
