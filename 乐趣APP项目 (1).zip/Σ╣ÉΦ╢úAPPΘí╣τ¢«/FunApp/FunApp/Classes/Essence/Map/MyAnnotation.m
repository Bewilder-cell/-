//
//  MyAnnotation.m
//  MapKitTest
//
//  Created by Rainy on 2017/12/1.
//  Copyright © 2017年 Rainy. All rights reserved.
//

#import "MyAnnotation.h"

@implementation MyAnnotation

@end
