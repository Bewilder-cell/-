//
//  FNTabBarController.m
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/19.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import "FNTabBarController.h"
#import "FNNavigationController.h"
#import "GFEssenceViewController.h"
#import "FNMeViewController.h"
#import "FNNewViewController.h"
#import "NPEditViewController.h"

@interface FNTabBarController () <UITabBarControllerDelegate>

@end

@implementation FNTabBarController

+(void)load
{
    UITabBarItem *titleItem = [UITabBarItem appearance];
    //正常
    NSMutableDictionary *normalDict = [NSMutableDictionary dictionary];
    normalDict[NSFontAttributeName] = [UIFont systemFontOfSize:13];
    normalDict[NSForegroundColorAttributeName] = [UIColor grayColor];
    [titleItem setTitleTextAttributes:normalDict forState:UIControlStateNormal];
    //选中
    NSMutableDictionary *selectedDict = [NSMutableDictionary dictionary];
    selectedDict[NSForegroundColorAttributeName] = [UIColor blackColor];
    [titleItem setTitleTextAttributes:selectedDict forState:UIControlStateSelected];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.delegate = self;
    
    //添加子控制器
    [self setUpAllChildView];
    
    //添加所有按钮内容
    [self setUpTabBarBtn];
    
}

#pragma mark - 添加所有按钮内容
-(void)setUpTabBarBtn
{
    FNNavigationController *nav = self.childViewControllers[0];
    nav.tabBarItem.title = @"精选";
    nav.tabBarItem.image = [UIImage imageNamed:@"tabBar_essence_icon"];
    nav.tabBarItem.selectedImage = [UIImage imageNamed:@"tabBar_essence_click_icon"];
    
    FNNavigationController *nav1 = self.childViewControllers[1];
    nav1.tabBarItem.title = @"";
    nav1.tabBarItem.image = [UIImage imageNamed:@"tabBar_publish_icon"];
    nav1.tabBarItem.selectedImage = [UIImage imageNamed:@"tabBar_publish_click_icon"];
    
    FNNavigationController *nav2 = self.childViewControllers[2];
    nav2.tabBarItem.title = @"我";
    nav2.tabBarItem.image = [UIImage imageNamed:@"tabBar_me_icon"];
    nav2.tabBarItem.selectedImage = [UIImage imageNamed:@"tabBar_me_click_icon"];
    
}

#pragma mark - 添加子控制器
-(void)setUpAllChildView
{
    //精华
    FNNavigationController *nav = [[FNNavigationController alloc]initWithRootViewController:[GFEssenceViewController new]];
    [self addChildViewController:nav];
    
    //新帖
    UIViewController *nav1 = [[FNNavigationController alloc]initWithRootViewController:[UIViewController new]];
    [self addChildViewController:nav1];
    
    //我
    FNNavigationController *nav2 = [[FNNavigationController alloc]initWithRootViewController:[FNMeViewController new]];
    [self addChildViewController:nav2];
    
}


- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController {
    
    if (viewController == [tabBarController.viewControllers objectAtIndex:1]){
        
        NPEditViewController *editVc = [NPEditViewController new];
        UINavigationController *inPutNav = [[UINavigationController alloc] initWithRootViewController:editVc];
        inPutNav.modalPresentationStyle = 0;
        editVc.saveItemBlock = ^(FNMyTopicModel *room) {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"UPDATE" object:nil];
        };

        [self presentViewController:inPutNav animated:YES completion:nil];
        
        return NO;
    }
    return true;
}


@end
