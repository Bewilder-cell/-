//
//  FNTabBarController.h
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/19.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FNTabBarController : UITabBarController

@end

NS_ASSUME_NONNULL_END
