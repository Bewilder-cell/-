//
//  FNMyTopicModel.m
//  FunApp
//
//  Created by 陈甸甸 on 2020/4/24.
//  Copyright © 2020 RocketsChen. All rights reserved.
//

#import "FNMyTopicModel.h"

@implementation FNMyTopicModel


#pragma mark - 联合主键
+ (NSArray *)bg_unionPrimaryKeys{
    return @[@"topic_id",@"topic_content"];
}


+ (NSMutableArray<FNMyTopicModel *>*)getAllMyTopicArray
{
    NSMutableArray <FNMyTopicModel *>*allArray = [NSMutableArray array];
    NSArray *allDataArray = [self bg_findAll:@"FNTopic"];
    for (FNMyTopicModel *eachItem in allDataArray) {
        [allArray addObject:eachItem];
    }
    return allArray;
}


+ (void)addTopicContentWith:(FNMyTopicModel *)topicModel
{
    topicModel.bg_tableName = @"FNTopic";
    [topicModel bg_saveOrUpdate];
}


+ (void)remoTopicContentWith:(FNMyTopicModel *)topicModel
{
    [self bg_delete:@"FNTopic" where:[NSString stringWithFormat:@"where %@=%@",bg_sqlKey(@"topic_id"),bg_sqlValue(topicModel.topic_id)]];
}

@end
