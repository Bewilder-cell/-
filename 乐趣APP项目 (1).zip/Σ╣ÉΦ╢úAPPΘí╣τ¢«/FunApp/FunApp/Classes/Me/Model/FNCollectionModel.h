//
//  FNCollectionModel.h
//  FunApp
//
//  Created by 陈甸甸 on 2020/4/23.
//  Copyright © 2020 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BGFMDB.h"

@class GFTopic;
@interface FNCollectionModel : NSObject


/* 收藏的id */
@property (strong , nonatomic) NSString *col_id;

/* 喜欢的内容 */
@property (strong , nonatomic) NSString *col_content;

/* 收藏的内容 */
@property (strong , nonatomic) GFTopic *topic;



+ (NSMutableArray<FNCollectionModel *>*)getAllColArray;


+ (BOOL)isAddColContentWith:(NSString *)col_id;


+ (void)addColContentWith:(FNCollectionModel *)colModel;


+ (void)remoColContentWith:(FNCollectionModel *)colModel;



@end

