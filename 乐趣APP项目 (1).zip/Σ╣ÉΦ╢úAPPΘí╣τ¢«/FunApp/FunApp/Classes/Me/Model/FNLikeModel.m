//
//  FNLikeModel.m
//  FunApp
//
//  Created by 陈甸甸 on 2020/4/23.
//  Copyright © 2020 RocketsChen. All rights reserved.
//

#import "FNLikeModel.h"

@implementation FNLikeModel

#pragma mark - 联合主键
+ (NSArray *)bg_unionPrimaryKeys{
    return @[@"like_id",@"like_content"];
}



+ (NSMutableArray<FNLikeModel *>*)getAllLikeArray
{
    NSMutableArray <FNLikeModel *>*allArray = [NSMutableArray array];
    NSArray *allDataArray = [self bg_findAll:@"FNLike"];
    for (FNLikeModel *eachItem in allDataArray) {
        [allArray addObject:eachItem];
    }
    return allArray;
}



+ (BOOL)isAddLikeContentWith:(NSString *)like_id
{
    BOOL add = false;
    
    for (FNLikeModel *eachItem in [self getAllLikeArray]) {
        if ([eachItem.like_id isEqualToString:like_id]) {
            add = true;
            break;
        }
    }
    
    return add;
}


+ (void)addLikeContentWith:(FNLikeModel *)likeModel
{
    likeModel.bg_tableName = @"FNLike";
    [likeModel bg_saveOrUpdate];
}


+ (void)remoLikeContentWith:(FNLikeModel *)likeModel
{
    [self bg_delete:@"FNLike" where:[NSString stringWithFormat:@"where %@=%@",bg_sqlKey(@"like_id"),bg_sqlValue(likeModel.like_id)]];
}

@end
