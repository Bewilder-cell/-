//
//  FNCollectionModel.m
//  FunApp
//
//  Created by 陈甸甸 on 2020/4/23.
//  Copyright © 2020 RocketsChen. All rights reserved.
//

#import "FNCollectionModel.h"

@implementation FNCollectionModel

#pragma mark - 联合主键
+ (NSArray *)bg_unionPrimaryKeys{
    return @[@"col_id",@"col_content"];
}



+ (NSMutableArray<FNCollectionModel *>*)getAllColArray
{
    NSMutableArray <FNCollectionModel *>*allArray = [NSMutableArray array];
    NSArray *allDataArray = [self bg_findAll:@"FNCollection"];
    for (FNCollectionModel *eachItem in allDataArray) {
        [allArray addObject:eachItem];
    }
    return allArray;
}



+ (BOOL)isAddColContentWith:(NSString *)col_id
{
    BOOL add = false;
    
    for (FNCollectionModel *eachItem in [self getAllColArray]) {
        if ([eachItem.col_id isEqualToString:col_id]) {
            add = true;
            break;
        }
    }
    
    return add;
}


+ (void)addColContentWith:(FNCollectionModel *)colModel;
{
    colModel.bg_tableName = @"FNCollection";
    [colModel bg_saveOrUpdate];
}


+ (void)remoColContentWith:(FNCollectionModel *)colModel
{
    [self bg_delete:@"FNCollection" where:[NSString stringWithFormat:@"where %@=%@",bg_sqlKey(@"col_id"),bg_sqlValue(colModel.col_id)]];
}


@end
