//
//  FNLikeModel.h
//  FunApp
//
//  Created by 陈甸甸 on 2020/4/23.
//  Copyright © 2020 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BGFMDB.h"


@interface FNLikeModel : NSObject

/* 喜欢的id */
@property (strong , nonatomic) NSString *like_id;

/* 喜欢的内容 */
@property (strong , nonatomic) NSString *like_content;

/* 字数 */
@property (strong , nonatomic) NSString *num;

+ (NSMutableArray<FNLikeModel *>*)getAllLikeArray;


+ (BOOL)isAddLikeContentWith:(NSString *)like_id;


+ (void)addLikeContentWith:(FNLikeModel *)likeModel;


+ (void)remoLikeContentWith:(FNLikeModel *)likeModel;

@end
