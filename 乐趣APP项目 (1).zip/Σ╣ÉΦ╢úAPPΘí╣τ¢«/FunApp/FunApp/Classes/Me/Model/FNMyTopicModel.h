//
//  FNMyTopicModel.h
//  FunApp
//
//  Created by 陈甸甸 on 2020/4/24.
//  Copyright © 2020 RocketsChen. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BGFMDB.h"

@interface FNMyTopicModel : NSObject


/* 帖子内容id */
@property (strong , nonatomic) NSString *topic_id;

/* 帖子内容 */
@property (strong , nonatomic) NSString *topic_content;

/* 创建时间*/
@property (strong , nonatomic) NSString *topic_time;

/* 字数 */
@property (strong , nonatomic) NSString *num;


+ (NSMutableArray<FNMyTopicModel *>*)getAllMyTopicArray;


+ (void)addTopicContentWith:(FNMyTopicModel *)topicModel;


+ (void)remoTopicContentWith:(FNMyTopicModel *)topicModel;


@end
