//
//  NPTextView.h
//  NotePad
//
//  Created by Pluto on 2019/12/19.
//  Copyright © 2019 MAC9. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NPTextView : UITextView

@property(nonatomic, assign) NSInteger maxLength;

/** 占位文字 */
@property (nonatomic, copy) NSString *placeholder;

/** 占位文字的颜色 */
@property (nonatomic, strong) UIColor *placeholderColor;

/** 代理事件 */
@property (nonatomic, copy) void(^textViewDeleagetBlock)(NSString *text);


@end

