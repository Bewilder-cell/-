//
//  NPTextView.m
//  NotePad
//
//  Created by Pluto on 2019/12/19.
//  Copyright © 2019 MAC9. All rights reserved.
//

#import "NPTextView.h"
#import "NPConst.h"
#import "UIView+DCExtension.h"

@interface NPTextView () <UITextViewDelegate>

/* 占位文字label */
@property (strong , nonatomic)UILabel *placeholderLabel;

@end

@implementation NPTextView

#pragma mark - 懒加载
-(UILabel *)placeholderLabel
{
    if (!_placeholderLabel) {
        UILabel *placeholderLabel = [[UILabel alloc] init];
        placeholderLabel.numberOfLines = 0;
        [self addSubview:placeholderLabel];
        _placeholderLabel = placeholderLabel;
        _placeholderLabel.dc_x = 4;
        _placeholderLabel.dc_y = 7;
        
    }
    return _placeholderLabel;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //竖直方向永远有弹簧效果
        self.alwaysBounceVertical = YES;
        
        self.delegate = self;
        
        self.font = [UIFont systemFontOfSize:15];
        
        self.placeholderColor = [UIColor lightGrayColor];

    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {
        //竖直方向永远有弹簧效果
        self.alwaysBounceVertical = YES;

        self.delegate = self;
        
        self.font = [UIFont systemFontOfSize:15];
        
        self.placeholderColor = [UIColor lightGrayColor];
    }
    
    return self;
}

/**
 主要是用于中文输入的场景
 剩余的允许输入的字数较少时，限制拼音字符的输入，提升体验
 */
- (NSInteger)allowMaxMarkLength:(NSInteger)remainLength
{
    NSInteger length = 0;
    if(remainLength > 2){
        length = NSIntegerMax;
    }else if(remainLength > 0){
        length = remainLength * 6;  //一个中文对应的拼音一般不超过6个
    }
    
    return length;
}

- (void)textViewDidChange:(UITextView *)textView
{
    if(_maxLength <= 0)return;
    [self textDidChange];
    
    NSString *text = textView.text;
    UITextRange *selectedRange = [textView markedTextRange];
    UITextPosition *position = [textView positionFromPosition:selectedRange.start offset:0];
    
    //没有高亮选择的字，则对已输入的文字进行字数统计和限制,防止中文/emoj被截断
    if (!position){
        if (text.length > _maxLength){
            NSRange rangeIndex = [text rangeOfComposedCharacterSequenceAtIndex:_maxLength];
            if (rangeIndex.length == 1){
                textView.text = [text substringToIndex:_maxLength];
            }else{
                if(_maxLength == 1){
                    textView.text = @"";
                }else{
                    NSRange rangeRange = [text rangeOfComposedCharacterSequencesForRange:NSMakeRange(0, _maxLength - 1 )];
                    textView.text = [text substringWithRange:rangeRange];
                }
            }
        }
        !_textViewDeleagetBlock ? : _textViewDeleagetBlock(textView.text);
    }
}

#pragma mark - 重写setter
- (void)setPlaceholderColor:(UIColor *)placeholderColor
{
    _placeholderColor = placeholderColor;
    
    self.placeholderLabel.textColor = placeholderColor;
}

- (void)setPlaceholder:(NSString *)placeholder
{
    _placeholder = [placeholder copy];
    
    self.placeholderLabel.text = placeholder;
    [self updatePlaceholderLabelSize];
    
}

- (void)setFont:(UIFont *)font
{
    [super setFont:font];
    self.placeholderLabel.font = font;
}

- (void)setText:(NSString *)text
{
    [super setText:text];
    
    [self textDidChange];
}

- (void)setAttributedText:(NSAttributedString *)attributedText
{
    [super setAttributedText:attributedText];
    
    [self textDidChange];
}


#pragma mark - 监听占位文字改变
- (void)textDidChange
{
    //占位文字现在是还是隐藏
    self.placeholderLabel.hidden = self.hasText;
}


/**
 更新占位文字的尺寸
 */
- (void)updatePlaceholderLabelSize
{
    CGSize maxSize = CGSizeMake(DCScreenW - 2 * self.placeholderLabel.dc_x, MAXFLOAT);
    self.placeholderLabel.dc_size = [_placeholder boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.font} context:nil].size;
}

/**
 * 更新占位文字的尺寸
 */
- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.placeholderLabel.dc_width = self.dc_width - 2 * self.placeholderLabel.dc_x;
    [self.placeholderLabel sizeToFit];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (CGRect)caretRectForPosition:(UITextPosition *)position {
    CGRect originalRect = [super caretRectForPosition:position];
    
    originalRect.size.height = self.font.lineHeight + 2;
    originalRect.size.width = 3;
    return originalRect;
}

@end
