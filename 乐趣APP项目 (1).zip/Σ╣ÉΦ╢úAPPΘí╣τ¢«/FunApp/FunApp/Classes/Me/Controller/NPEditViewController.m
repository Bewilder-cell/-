//
//  NPEditViewController.m
//  NotePad
//
//  Created by Pluto on 2019/12/19.
//  Copyright © 2019 MAC9. All rights reserved.
//

#import "NPEditViewController.h"

// Controllers

// Models
#import "FNMyTopicModel.h"
// Views
#import "NPTextView.h"
// ViewModels

// Vendors
#import "NPConst.h"
#import "SnToast.h"
#import "NPQuickMethod.h"
#import "MBProgressHUD.h"

// Categories
#import "UIView+DCExtension.h"
// Others

@interface NPEditViewController ()
{
    int imageIndex_;
}

/* 日期 */
@property (strong , nonatomic) UILabel *dateLabel;

/* 编辑 */
@property (strong , nonatomic) UILabel *creatLabel;

/* 输入 */
@property (strong , nonatomic) UILabel *inPutCountLabel;

/* contentTextView */
@property (strong , nonatomic) NPTextView *contentTextView;

@end

@implementation NPEditViewController

- (UILabel *)dateLabel
{
    if (!_dateLabel) {
        _dateLabel = [UILabel new];
        _dateLabel.font = [UIFont systemFontOfSize:16];
        _dateLabel.frame = CGRectMake(10, 45, 200, 30);
        _dateLabel.textColor = [UIColor darkGrayColor];
        [self.view addSubview:_dateLabel];
    }
    return _dateLabel;
}


- (UILabel *)creatLabel
{
    if (!_creatLabel) {
        _creatLabel = [UILabel new];
        _creatLabel.font = [UIFont systemFontOfSize:14];
        _creatLabel.textAlignment = NSTextAlignmentCenter;
        _creatLabel.frame = CGRectMake(DCScreenW * 0.5 - 100, 10, 200, 30);
        _creatLabel.textColor = [UIColor darkGrayColor];
        [self.view addSubview:_creatLabel];
    }
    return _creatLabel;
}


- (NPTextView *)contentTextView
{
    if (!_contentTextView) {
        _contentTextView = [[NPTextView alloc] initWithFrame:CGRectMake(10, self.dateLabel.dc_bottom + 20, DCScreenW - 20, DCScreenH - NavigationBarHeight - (self.dateLabel.dc_bottom + 40))];
        _contentTextView.maxLength = CGFLOAT_MAX;
        _contentTextView.placeholder = @"请输入您要记录的内容";
        _contentTextView.font = [UIFont systemFontOfSize:18];
        [self.view insertSubview:_contentTextView atIndex:0];
    }
    return _contentTextView;
}


- (UILabel *)inPutCountLabel
{
    if (!_inPutCountLabel) {
        _inPutCountLabel = [UILabel new];
        _inPutCountLabel.font = [UIFont systemFontOfSize:12];
        _inPutCountLabel.frame = CGRectMake(DCScreenW - 215, 45, 200, 30);
        _inPutCountLabel.textAlignment = NSTextAlignmentRight;
        _inPutCountLabel.textColor = [UIColor darkGrayColor];
        [self.view addSubview:_inPutCountLabel];
    }
    return _inPutCountLabel;
}



- (void)viewDidLoad {
    [super viewDidLoad];
        
    [self setUpBase];
    
    [self setUpNav];
    
    [self setUpAcceptNote];
}


- (void)setUpAcceptNote
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidHide:) name:UIKeyboardWillHideNotification object:nil];
}


- (void)setUpBase
{
    self.title = @"我的动态";
    self.view.backgroundColor = [UIColor whiteColor];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
    NSDate *datenow = [NSDate date];
    NSString *currentTimeString = [formatter stringFromDate:datenow];
    self.dateLabel.text = currentTimeString;
    __weak typeof(self)weakSelf = self;
    self.contentTextView.textViewDeleagetBlock = ^(NSString *text) {
        weakSelf.inPutCountLabel.text = [NSString stringWithFormat:@"已编辑：%zd",text.length];
    };
}


- (void)setUpNav
{
    UIButton *saveButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [saveButton setTitle:@"发布" forState:0];
    saveButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [saveButton setTitleColor:[UIColor blackColor] forState:0];
    saveButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [saveButton sizeToFit];
    [saveButton addTarget:self action:@selector(saveButtonClick) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:saveButton];
    
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setTitle:@"取消" forState:0];
    backButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [backButton setTitleColor:[UIColor blackColor] forState:0];
    backButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [backButton sizeToFit];
    [backButton addTarget:self action:@selector(backButtonClick) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
}

#pragma mark --键盘弹出
- (void)keyboardWillChangeFrame:(NSNotification *)notification{
    
    CGFloat duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
    CGRect keyboardFrame = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    __weak typeof(self)weakSelf = self;
    [UIView animateWithDuration:duration animations:^{
        weakSelf.dateLabel.dc_y = keyboardFrame.origin.y - 30;
        weakSelf.inPutCountLabel.dc_y = keyboardFrame.origin.y - 30;
    }];
}

#pragma mark --键盘收回
- (void)keyboardDidHide:(NSNotification *)notification{
    CGFloat duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
    __weak typeof(self)weakSelf = self;
    [UIView animateWithDuration:duration animations:^{
        weakSelf.dateLabel.dc_y = 45;
        weakSelf.inPutCountLabel.dc_y = 45;
    }];
}


#pragma mark - 返回
- (void)backButtonClick
{
    [self.view endEditing:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - 更新
- (void)saveButtonClick
{
    [self.view endEditing:YES];
    FNMyTopicModel *saveNodel = [FNMyTopicModel new];
    saveNodel.topic_id = [NSString stringWithFormat:@"topic_%zd",[FNMyTopicModel getAllMyTopicArray].count];
    saveNodel.topic_content = self.contentTextView.text;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
    NSDate *datenow = [NSDate date];
    NSString *currentTimeString = [formatter stringFromDate:datenow];
    saveNodel.topic_time = currentTimeString;
    saveNodel.num = [NSString stringWithFormat:@"%zd",self.contentTextView.text.length];
    [FNMyTopicModel addTopicContentWith:saveNodel];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    __weak typeof(self)weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:weakSelf.view animated:YES];
        [SnToast showBottomWithText:@"更新成功"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            !weakSelf.saveItemBlock ? : weakSelf.saveItemBlock(saveNodel);
            [self dismissViewControllerAnimated:YES completion:nil];
        });
    });
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}



@end
