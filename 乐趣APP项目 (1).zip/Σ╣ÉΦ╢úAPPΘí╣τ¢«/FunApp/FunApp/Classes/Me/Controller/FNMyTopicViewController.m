//
//  FNCollectionViewController.m
//  FunApp
//
//  Created by 陈甸甸 on 2020/4/23.
//  Copyright © 2020 RocketsChen. All rights reserved.
//

#import "FNMyTopicViewController.h"
#import "NPEditViewController.h"
#import "GFTopic.h"
#import "GFTopicCell.h"
#import "FNCollectionModel.h"
#import "FNMyTopicModel.h"
#import <AFNetworking.h>
#import <MJExtension.h>
#import <SVProgressHUD.h>
#import <UIImageView+WebCache.h>
#import <SDImageCache.h>
#import "FNUserModel.h"
#import "FNCollectionModel.h"

static NSString *const topicID = @"topic";

@interface FNMyTopicViewController ()
/*所有帖子数据*/
@property (strong , nonatomic)NSMutableArray<GFTopic *> *topics;
/*maxtime*/
@property (strong , nonatomic)NSString *maxtime;

/*请求管理者*/
@property (strong , nonatomic)GFHTTPSessionManager *manager;


@end

@implementation FNMyTopicViewController

#pragma mark - 初始化
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUpTable];
    
    [self setupData];
    
    [self setUpNav];

}

- (void)setUpNav
{
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"发表动态" style:UIBarButtonItemStyleDone target:self action:@selector(published)];
    [self.navigationItem.rightBarButtonItem setTintColor:[UIColor blackColor]];
    
    __weak typeof(self)weakSelf = self;
    [[NSNotificationCenter defaultCenter] addObserverForName:@"UPDATE" object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
        [weakSelf setupData];
    }];
}

- (void)published
{
    NPEditViewController *editVc = [NPEditViewController new];
    __weak typeof(self)weakSelf = self;
    editVc.saveItemBlock = ^(FNMyTopicModel *room) {
        [weakSelf setupData];
    };
    UINavigationController *inPutNav = [[UINavigationController alloc] initWithRootViewController:editVc];
    inPutNav.modalPresentationStyle = 0;
    [self presentViewController:inPutNav animated:YES completion:nil];
}


- (void)setShowHome:(BOOL)showHome
{
    if (showHome) {
        self.tableView.contentInset = UIEdgeInsetsMake(GFTitleViewH + NavigationBarHeight, 0, tabBarHt, 0);
    }
}

- (void)setUpTable
{
    self.title = @"我的动态";
    self.tableView.contentInset = UIEdgeInsetsMake(NavigationBarHeight, 0, staBarHt, 0);
    self.tableView.scrollIndicatorInsets = self.tableView.contentInset;
    self.tableView.backgroundColor = GFBgColor;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([GFTopicCell class]) bundle:nil] forCellReuseIdentifier:topicID];
}

- (void)setupData
{
    self.topics = [NSMutableArray array];
    for (FNMyTopicModel *model in [FNMyTopicModel getAllMyTopicArray]) {
        GFTopic *topic = [GFTopic new];
        topic.ID = model.topic_id;
        topic.text = model.topic_content;
        topic.created_at = model.topic_time;
        topic.profile_image = @"me";
        topic.name = [FNUserModel getCurrentUserItem].user_name;
        topic.type = GFTopicTypeWord;
        [self.topics addObject:topic];
    }
    [self.tableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.topics.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    GFTopicCell *cell = [tableView dequeueReusableCellWithIdentifier:topicID forIndexPath:indexPath];
    
    GFTopic *topic = self.topics[indexPath.row];
    cell.topic = topic;
    
    return cell;
}

#pragma mark - 代理方法
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    GFTopic *topic = _topics[indexPath.row];
    
    return topic.cellHeight;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [[SDImageCache sharedImageCache] clearMemory];
}



- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [SVProgressHUD dismiss];
}

@end
