//
//  NPEditViewController.h
//  NotePad
//
//  Created by Pluto on 2019/12/19.
//  Copyright © 2019 MAC9. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "FNMyTopicModel.h"

@interface NPEditViewController : UIViewController


@property(nonatomic, copy) void (^saveItemBlock)(FNMyTopicModel *room);

@end
