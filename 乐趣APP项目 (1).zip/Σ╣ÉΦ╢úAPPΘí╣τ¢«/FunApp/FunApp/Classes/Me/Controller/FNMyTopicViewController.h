//
//  FNMyTopicViewController.h
//  FunApp
//
//  Created by 陈甸甸 on 2020/4/24.
//  Copyright © 2020 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FNMyTopicViewController : UITableViewController

/* 首页展示 */
@property (nonatomic, assign) BOOL showHome;


@end

NS_ASSUME_NONNULL_END
