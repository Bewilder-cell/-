//
//  FNMeViewController.m
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/21.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import "FNMeViewController.h"
#import "FNUserModel.h"
#import "NPQuickMethod.h"
#import "FNNavigationController.h"
#import "FNLoginViewController.h"
#import "FNCollectionViewController.h"
#import "FNMyTopicViewController.h"
#import <SDImageCache.h>

@interface FNMeViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *uerNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;

@end

@implementation FNMeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUpBase];
    
}


- (void)setUpBase
{
    self.view.backgroundColor = [UIColor whiteColor];
    self.iconImageView.image = [UIImage imageNamed:[FNUserModel getCurrentUserItem].user_icon];
    self.uerNameLabel.text = [NSString stringWithFormat:@"尊敬的用户：%@",[FNUserModel getCurrentUserItem].user_name];
    self.emailLabel.text =  [NSString stringWithFormat:@"注册邮箱：%@",[FNUserModel getCurrentUserItem].user_email];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}



#pragma mark - 我得动态
- (IBAction)dynamicClick:(id)sender {
    
    FNMyTopicViewController *myTopicVc = [FNMyTopicViewController new];
    [self.navigationController pushViewController:myTopicVc animated:true];
}


#pragma mark - 收藏
- (IBAction)collectionClick:(id)sender {
    
    FNCollectionViewController *colVc = [FNCollectionViewController new];
    [self.navigationController pushViewController:colVc animated:true];
    
}



#pragma mark - 更换用户名
- (IBAction)changeName:(id)sender {
    
    __weak typeof(self)weakSelf = self;
    [NPQuickMethod dc_SetUpAlterWithView:self Message:@"是否更换用户名" Sure:^{

        UIAlertController *titleAlter = [UIAlertController alertControllerWithTitle:@"新用户名" message:nil preferredStyle:UIAlertControllerStyleAlert];
        [titleAlter addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = @"请输入新用户名";
        }];
        
        UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *saveBtn = [UIAlertAction actionWithTitle:@"保存" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSString *name = titleAlter.textFields[0].text;
            FNUserModel *current = [FNUserModel getCurrentUserItem];
            current.user_name = name;
            [current bg_saveOrUpdate];
            weakSelf.uerNameLabel.text = [NSString stringWithFormat:@"尊敬的用户：%@",current.user_name];
            [[NSUserDefaults standardUserDefaults] setObject:name forKey:UserName];
        }];
        [titleAlter addAction:cancelBtn];
        [titleAlter addAction:saveBtn];
        
        [weakSelf presentViewController:titleAlter animated:YES completion:nil];
    
    } Cancel:nil];
    
    
    
    
}


#pragma mark - 更换随机头像
- (IBAction)changeIcon:(id)sender {
    __weak typeof(self)weakSelf = self;
    [NPQuickMethod dc_SetUpSheetWithView:self WithTitle:@"更换图片" Message:nil ContentArray:@[@"图片1",@"图片2",@"图片3",@"图片4",@"图片5"] CancelTitle:@"不更换" CancelBlock:nil ContentClickBlock:^(NSInteger index, NSString *titleName) {

        FNUserModel *current = [FNUserModel getCurrentUserItem];
        current.user_icon = @[@"icon_1",@"icon_2",@"icon_3",@"icon_4",@"icon_5"][index];
        [current bg_saveOrUpdate];
        weakSelf.iconImageView.image = [UIImage imageNamed:current.user_icon];

    } CompletionBlock:nil];
}


#pragma mark - 清除缓存
- (IBAction)cleanCache:(id)sender {
    
    __weak typeof(self)weakSelf = self;
    CGFloat size = [SDImageCache sharedImageCache].totalDiskSize / 1000.0 / 1000;
    [NPQuickMethod dc_SetUpAlterWithView:self Message:[NSString stringWithFormat:@"清除缓存（已使用%.2fMB）", size] Sure:^{
        [MBProgressHUD showHUDAddedTo:weakSelf.view animated:YES];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[SDImageCache sharedImageCache] clearMemory];
            [[SDImageCache sharedImageCache] clearDiskOnCompletion:nil];
            [MBProgressHUD hideHUDForView:weakSelf.view animated:YES];
            [SnToast showBottomWithText:@"清除成功"];
        });
    } Cancel:nil];
}



#pragma mark - 退出登录
- (IBAction)loginOff:(id)sender {
    
    __weak typeof(self)weakSelf = self;
    [NPQuickMethod dc_SetUpAlterWithView:self Message:@"是否确认注销当前用户？" Sure:^{
        [MBProgressHUD showHUDAddedTo:weakSelf.view animated:YES];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:weakSelf.view animated:YES];
            [SnToast showBottomWithText:@"注销成功"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [UIApplication sharedApplication].keyWindow.rootViewController = [[FNNavigationController alloc] initWithRootViewController:[FNLoginViewController new]];
                [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:UserName];
                NSMutableDictionary *userDict = [NSMutableDictionary dictionary];
                [userDict setObject:@"" forKey:@"name"];
                [userDict setObject:@"" forKey:@"pwd"];
                [[NSUserDefaults standardUserDefaults] setObject:userDict forKey:RememberPassword];
            });
        });
        
    } Cancel:nil];
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}


@end
