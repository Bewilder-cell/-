//
//  AppDelegate.m
//  FunApp
//
//  Created by 陈甸甸 on 2019/12/19.
//  Copyright © 2019 RocketsChen. All rights reserved.
//

#import "AppDelegate.h"
#import "FNTabBarController.h"
#import "FNNavigationController.h"
#import "FNLoginViewController.h"
#import <SDWebImage.h>

#import "MyAnnotation.h"
#import "YGMapManagerView.h"

@interface AppDelegate ()

@property (nonatomic, strong)CLLocationManager *manager;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];

    NSString *lastName = [[NSUserDefaults standardUserDefaults] objectForKey:UserName];
    if ([[NSUserDefaults standardUserDefaults] objectForKey:RememberPassword] && lastName.length > 0) {
        FNTabBarController *tabVc = [[FNTabBarController alloc] init];
        self.window.rootViewController = tabVc;
        [SnToast showBottomWithText:@"自动登录成功"];
    }else{
        self.window.rootViewController = [[FNNavigationController alloc] initWithRootViewController:[FNLoginViewController new]];
    }
    
    [NSThread sleepForTimeInterval:0.5];
    
    [self setUpFixiOS11];
    
    [self.window makeKeyAndVisible];
    
    _manager = [CLLocationManager new];
    [_manager requestWhenInUseAuthorization];

    return YES;
}


#pragma mark - APP receives a memory alert.
- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
    [[SDWebImageManager sharedManager] cancelAll]; //Cancel Download
}

#pragma mark - 适配
- (void)setUpFixiOS11
{
    if (@available(ios 11.0,*)) {
        UIScrollView.appearance.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        UITableView.appearance.estimatedRowHeight = 0;
        UITableView.appearance.estimatedSectionFooterHeight = 0;
        UITableView.appearance.estimatedSectionHeaderHeight = 0;
    }
}



@end
